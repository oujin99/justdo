package com.koreait.querydsl.dto;

import lombok.Data;

@Data
public class UserDto {
	private String name;
	private int age;
}
