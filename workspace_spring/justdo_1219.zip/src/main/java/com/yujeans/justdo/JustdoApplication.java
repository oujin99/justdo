package com.yujeans.justdo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JustdoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JustdoApplication.class, args);
	}

}
